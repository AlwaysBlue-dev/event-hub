/**
 * HTML elements that can be decoded.
 */
export type HTMLVisualMediaElement = HTMLVideoElement | HTMLImageElement;
