import CharacterSetECI from '../common/CharacterSetECI';

/**
 * Just to make a shortcut between Java code and TS code.
 */
export default class StandardCharsets {
  public static ISO_8859_1 = CharacterSetECI.ISO8859_1;
}
